# Zipcart Stock Control Tower — Full-stack starter

A simple full-stack inventory-risk demo for a 30-store grocery delivery network.

## Requirements
- Node.js 18 or newer
- No npm packages required; this app uses Node's built-in HTTP server and a JSON file database.

## Start
1. Extract this ZIP to a folder.
2. Open a terminal/Command Prompt in that folder.
3. Run: `npm start` (or `node server.js`)
4. Open `http://localhost:3000`

## Features
- Dashboard summary based on inventory data
- Search, store filter, and stock-risk filter
- Demand-based minutes-to-stockout calculation
- Create transfer endpoint validates source stock and destination, moves quantities between inventory records, and saves a transfer history
- Edit on-hand stock
- Update next-truck ETA in Settings
- Persistent JSON storage at `data/db.json`

## Deploy a public demo (Render)
1. Push this folder to a GitHub repository.
2. In Render, create a new **Web Service** and connect that repository.
3. Use build command `npm install` and start command `npm start`.
4. Choose the Free instance for a demo and deploy.

**Demo limitation:** `data/db.json` is local-file storage. On free hosting, file changes may be lost after restarts or redeploys. This is sample data only; use a managed database for persistent data.

## API endpoints
- `GET /api/health`
- `GET /api/summary`
- `GET /api/stores`
- `GET /api/products`
- `GET /api/inventory?q=&risk=&store=`
- `PATCH /api/inventory/:id` body example: `{"onHand":24}` or `{"demandPerHour":8}`
- `GET /api/transfers`
- `POST /api/transfers` body example:
  `{"fromStore":"Store 04 · Vijayanagar","toStore":"Store 12 · Indiranagar","product":"Full cream milk 1L","quantity":12}`
- `GET /api/settings`
- `PATCH /api/settings` body example: `{"nextTruckMinutes":30}`

## Important production notes
This is a functional local prototype, not a production deployment. The sample data is synthetic. Before using it for real operations, add authentication and role-based access, input audit logs, a real database (PostgreSQL/MySQL), concurrent-write protection, secure deployment/HTTPS, monitoring, and integrations to POS, order demand, warehouse stock, and truck GPS/ETA systems. "Transfer completed" currently means inventory is immediately rebalanced in the demo; it does not dispatch a physical vehicle.
