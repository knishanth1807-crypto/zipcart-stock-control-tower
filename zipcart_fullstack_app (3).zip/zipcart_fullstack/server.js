const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { URL } = require("node:url");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

const seedStores = [
  ["Store 01 · Basavanagudi","Basavanagudi"],["Store 02 · Malleshwaram","Malleshwaram"],
  ["Store 03 · HSR Layout","HSR Layout"],["Store 04 · Vijayanagar","Vijayanagar"],
  ["Store 05 · Hebbal","Hebbal"],["Store 06 · Yeshwanthpur","Yeshwanthpur"],
  ["Store 07 · Koramangala","Koramangala"],["Store 08 · Banashankari","Banashankari"],
  ["Store 09 · Jayanagar","Jayanagar"],["Store 10 · Domlur","Domlur"],
  ["Store 11 · BTM Layout","BTM Layout"],["Store 12 · Indiranagar","Indiranagar"],
  ["Store 13 · Kalyan Nagar","Kalyan Nagar"],["Store 14 · Rajajinagar","Rajajinagar"],
  ["Store 15 · Vijaya Bank Layout","Vijaya Bank Layout"],["Store 16 · Bellandur","Bellandur"],
  ["Store 17 · Frazer Town","Frazer Town"],["Store 18 · JP Nagar","JP Nagar"],
  ["Store 19 · Electronic City","Electronic City"],["Store 20 · Nagarbhavi","Nagarbhavi"],
  ["Store 21 · Whitefield","Whitefield"],["Store 22 · RT Nagar","RT Nagar"],
  ["Store 23 · Sarjapur Road","Sarjapur Road"],["Store 24 · Kengeri","Kengeri"],
  ["Store 25 · Marathahalli","Marathahalli"],["Store 26 · Banaswadi","Banaswadi"],
  ["Store 27 · Yelahanka","Yelahanka"],["Store 28 · Peenya","Peenya"],
  ["Store 29 · Shivajinagar","Shivajinagar"],["Store 30 · MG Road","MG Road"]
];
const catalog = [
 ["Full cream milk 1L","🥛"],["Bananas 6 pcs","🍌"],["Whole wheat bread","🍞"],["Eggs 6 pack","🥚"],
 ["Drinking water 1L","💧"],["Curd 500g","🥣"],["Tomatoes 500g","🍅"],["Potato 1kg","🥔"],
 ["Paneer 200g","🧀"],["Onion 1kg","🧅"],["Apples 4 pcs","🍎"],["Oats 500g","🥣"],
 ["Orange juice 1L","🧃"],["Atta 5kg","🌾"],["Butter 100g","🧈"],["Coffee 100g","☕"],
 ["Rice 5kg","🍚"],["Chicken 500g","🍗"],["Dish soap 500ml","🧴"],["Cucumber 500g","🥒"],
 ["Toor dal 1kg","🫘"],["Ice cream 500ml","🍨"],["Lemons 4 pcs","🍋"],["Detergent 1kg","🫧"],
 ["Coconut water","🥥"],["Carrots 500g","🥕"],["Yogurt 400g","🥛"]
];
const seedRisk = [
 ["Store 12 · Indiranagar","Full cream milk 1L",8,19,24],["Store 07 · Koramangala","Bananas 6 pcs",6,16,18],
 ["Store 03 · HSR Layout","Whole wheat bread",4,14,12],["Store 21 · Whitefield","Eggs 6 pack",11,27,30],
 ["Store 09 · Jayanagar","Drinking water 1L",18,35,24],["Store 16 · Bellandur","Curd 500g",9,22,20],
 ["Store 02 · Malleshwaram","Tomatoes 500g",13,29,16],["Store 25 · Marathahalli","Potato 1kg",22,43,24],
 ["Store 11 · BTM Layout","Paneer 200g",14,31,18],["Store 14 · Rajajinagar","Onion 1kg",28,55,20],
 ["Store 05 · Hebbal","Apples 4 pcs",16,38,12],["Store 19 · Electronic City","Oats 500g",20,47,15],
 ["Store 08 · Banashankari","Orange juice 1L",7,18,14],["Store 27 · Yelahanka","Atta 5kg",31,62,20],
 ["Store 30 · MG Road","Butter 100g",10,25,13],["Store 04 · Vijayanagar","Full cream milk 1L",68,120,0],
 ["Store 18 · JP Nagar","Bananas 6 pcs",52,105,0],["Store 22 · RT Nagar","Whole wheat bread",41,90,0]
];
function seedDb() {
  const inventory = [];
  for (const [store, area] of seedStores) {
    for (const [idx, [product, emoji]] of catalog.entries()) {
      const special = seedRisk.find(x => x[0] === store && x[1] === product);
      const onHand = special ? special[2] : ((store.charCodeAt(7) * 3 + idx * 7) % 44) + 8;
      const demandPerHour = special ? Math.max(1, Math.round(onHand / special[3] * 60)) : ((idx * 3 + store.charCodeAt(7)) % 12) + 2;
      inventory.push({
        id: `${store.split(" · ")[0].replace(" ","-")}-${idx+1}`, store, area, product, emoji,
        onHand, demandPerHour, leadTimeMin: 42, updatedAt: new Date().toISOString()
      });
    }
  }
  return { stores: seedStores.map(([name, area]) => ({name, area})), inventory, transfers: [], settings: {nextTruckMinutes:42, truckCapacityUnits:400} };
}
let db;
try { db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, "utf8")) : seedDb(); }
catch { db = seedDb(); }
function saveDb() { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
if (!fs.existsSync(DB_FILE)) saveDb();

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,POST,PATCH,DELETE,OPTIONS","Access-Control-Allow-Headers":"Content-Type"});
  res.end(body);
}
function bodyJson(req) {
  return new Promise((resolve, reject) => {
    let raw = ""; req.on("data", c => { raw += c; if (raw.length > 1e6) req.destroy(); });
    req.on("end", () => { try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new Error("Invalid JSON body")); } });
    req.on("error", reject);
  });
}
function riskFor(item) {
  const minutes = item.demandPerHour > 0 ? Math.round(item.onHand / item.demandPerHour * 60) : 9999;
  const risk = minutes <= 20 ? "Critical" : minutes <= 45 ? "High" : minutes <= 75 ? "Watch" : "Healthy";
  const suggested = Math.max(0, Math.ceil(item.demandPerHour * (db.settings.nextTruckMinutes + 15) / 60 - item.onHand));
  return {...item, minutesToStockout:minutes, risk, suggestedUnits:suggested};
}
function summary() {
  const scored = db.inventory.map(riskFor);
  const urgent = scored.filter(x => x.risk === "Critical" || x.risk === "High");
  const riskyStores = new Set(urgent.map(x => x.store));
  return {stores:db.stores.length, storesAtRisk:riskyStores.size, predictedStockouts:scored.filter(x=>x.minutesToStockout<db.settings.nextTruckMinutes).length,
    unitsToMove:scored.reduce((n,x)=>n+x.suggestedUnits,0), nextTruckMinutes:db.settings.nextTruckMinutes,
    criticalCount:scored.filter(x=>x.risk==="Critical").length, highCount:scored.filter(x=>x.risk==="High").length,
    agingRiskPct:3.8, transfersCreated:db.transfers.length};
}
const server = http.createServer(async (req,res) => {
  if (req.method === "OPTIONS") return json(res,204,{});
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const p = url.pathname;
  try {
    if (p.startsWith("/api/")) {
      if (p === "/api/health" && req.method === "GET") return json(res,200,{ok:true, service:"Zipcart API"});
      if (p === "/api/summary" && req.method === "GET") return json(res,200,summary());
      if (p === "/api/stores" && req.method === "GET") return json(res,200,db.stores);
      if (p === "/api/products" && req.method === "GET") return json(res,200,[...new Set(db.inventory.map(x=>x.product))].sort());
      if (p === "/api/inventory" && req.method === "GET") {
        let data = db.inventory.map(riskFor);
        const q = (url.searchParams.get("q") || "").toLowerCase();
        const risk = url.searchParams.get("risk") || "all";
        const store = url.searchParams.get("store") || "all";
        data = data.filter(x => (!q || `${x.store} ${x.product} ${x.area}`.toLowerCase().includes(q)) &&
          (risk==="all" || x.risk===risk) && (store==="all" || x.store===store));
        data.sort((a,b)=>(({Critical:0,High:1,Watch:2,Healthy:3}[a.risk]) - ({Critical:0,High:1,Watch:2,Healthy:3}[b.risk])) || a.minutesToStockout-b.minutesToStockout);
        return json(res,200,data);
      }
      if (p === "/api/transfers" && req.method === "GET") return json(res,200,db.transfers);
      if (p === "/api/transfers" && req.method === "POST") {
        const b = await bodyJson(req);
        const qty = Number(b.quantity);
        if (!b.fromStore || !b.toStore || b.fromStore===b.toStore || !b.product || !Number.isInteger(qty) || qty<1)
          return json(res,400,{error:"Choose different source and destination stores, a product, and a whole quantity of at least 1."});
        const source = db.inventory.find(x=>x.store===b.fromStore && x.product===b.product);
        const target = db.inventory.find(x=>x.store===b.toStore && x.product===b.product);
        if (!source || !target) return json(res,404,{error:"Inventory item not found for the selected store/product."});
        if (source.onHand < qty) return json(res,400,{error:`Source store only has ${source.onHand} units available.`});
        source.onHand -= qty; target.onHand += qty;
        source.updatedAt = target.updatedAt = new Date().toISOString();
        const transfer = {id:`TR-${Date.now().toString().slice(-8)}`, fromStore:b.fromStore, toStore:b.toStore, product:b.product, quantity:qty, status:"Completed", createdAt:new Date().toISOString()};
        db.transfers.unshift(transfer); saveDb();
        return json(res,201,{transfer,summary:summary()});
      }
      if (p.startsWith("/api/inventory/") && req.method === "PATCH") {
        const id = decodeURIComponent(p.slice("/api/inventory/".length));
        const b = await bodyJson(req); const item = db.inventory.find(x=>x.id===id);
        if (!item) return json(res,404,{error:"Inventory record not found."});
        if (b.onHand !== undefined) {
          const n = Number(b.onHand); if (!Number.isInteger(n) || n<0) return json(res,400,{error:"On-hand quantity must be a whole number of 0 or more."});
          item.onHand=n;
        }
        if (b.demandPerHour !== undefined) {
          const n=Number(b.demandPerHour); if (!Number.isFinite(n) || n<0) return json(res,400,{error:"Demand must be 0 or more."});
          item.demandPerHour=n;
        }
        item.updatedAt=new Date().toISOString(); saveDb(); return json(res,200,riskFor(item));
      }
      if (p === "/api/settings" && req.method === "GET") return json(res,200,db.settings);
      if (p === "/api/settings" && req.method === "PATCH") {
        const b=await bodyJson(req);
        if (b.nextTruckMinutes !== undefined) { const n=Number(b.nextTruckMinutes); if(!Number.isFinite(n)||n<1||n>360)return json(res,400,{error:"Truck ETA must be between 1 and 360 minutes."}); db.settings.nextTruckMinutes=n; }
        saveDb(); return json(res,200,db.settings);
      }
      return json(res,404,{error:"API endpoint not found"});
    }
    let filePath = p === "/" ? path.join(PUBLIC,"index.html") : path.join(PUBLIC, path.normalize(p).replace(/^(\.\.[/\\])+/, ""));
    if (!filePath.startsWith(PUBLIC)) return json(res,403,{error:"Forbidden"});
    if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return json(res,404,{error:"Not found"});
    const ext=path.extname(filePath); const types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8"};
    res.writeHead(200,{"Content-Type":types[ext]||"application/octet-stream"}); fs.createReadStream(filePath).pipe(res);
  } catch (e) { json(res,500,{error:"Server error",detail:e.message}); }
});
server.listen(PORT, "0.0.0.0", () => console.log(`Zipcart running on port ${PORT}`));
